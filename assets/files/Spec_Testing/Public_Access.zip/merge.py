import argparse
from operator import concat
import sys
from unicodedata import name
import ruamel.yaml
import warnings
from ruamel.yaml.error import ReusedAnchorWarning
warnings.simplefilter("ignore", ReusedAnchorWarning)
import os
import glob

def concat(args):
  project={}
  
  pathname=args.filepath
  if os.path.isfile(pathname):
    res={}
    data=[]
    yaml=ruamel.yaml.YAML(typ='safe',pure=True)
    project=yaml.load(open(pathname))
    res['project-name']=project['project-name']
    res['project-uaid']=project['project-uaid']
    res['config']=project['config']
    del res['config']['maxSecondsBetweenRuns']
    data.append(res)
  elif os.path.isdir(pathname):
    data=[]
    flag=1
    res={}
    res['config']=[]
  
    for file_name in sorted(glob.glob('*.yaml')):
        if flag==1:
            yaml=ruamel.yaml.YAML(typ='safe',pure=True)
            project=yaml.load(open(file_name))
            res['project-name']=project['project-name']
            res['project-uaid']=project['project-uaid']
            res['config']=project['config']
            
            data.append(res)
            flag=0
        else:
            yaml=ruamel.yaml.YAML(typ='safe',pure=True)
            project=yaml.load(open(file_name))
            res=project['config']['scenarios']
            
            data.append(res)
            flag=0
  finalpath=args.concat_filepath
  with open(finalpath, 'w') as file:
    documents = ruamel.yaml.dump(data, file, allow_unicode=True, default_flow_style=False)

  return "Concatenated file in given path"

if __name__== '__main__':
  parser=argparse.ArgumentParser()
  parser.add_argument('--filepath',type=str, help="Enter file path for yaml file(s)")
  parser.add_argument('--concat_filepath',type=str, help="Enter file path for concatenated yaml file")

  args = parser.parse_args()

  sys.stdout.write(concat(args))